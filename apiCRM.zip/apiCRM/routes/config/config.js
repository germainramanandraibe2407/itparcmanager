module.exports = {
    jwtSecret: 'my-secret-key'
  }