const express = require('express');
var app=express();
const bodyparser=require('body-parser');
const path=require('path');
const mysql = require('mysql');
const router = express.Router();


 
//ajout du middleware body-parser
app.use(bodyparser.json());    
 
//set upp public directory to serve static files
console.log(__dirname)
app.use(express.static('public'));
// Créer une connexion à la base de données
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'itparcmanager'
  });
  
  
// Se connecter à la base de données
connection.connect((err) => {
    if (err) {
      console.error('Erreur de connexion à la base de données:', err);
      return;
    }
    console.log('Connexion à la base de données réussie');
  });
  

  router.get('/Mouvement', function(req, res) {
    const sql = 'SELECT * FROM mouvements left join materiels on mouvements.idmateriels=materiels.idMateriels '
   //JOIN commandes ON materiels.idcommande=commandes.idcommandes JOIN consommables ON materiels.idconsommable=consommables.idconsommables JOIN services ON materiels.idservice=services.idservices 
    connection.query(sql, [], function(err, results) {
      if (err) throw err;
      res.send(results); 
    });
  });


  router.post('/Mouvement/retour', function(req, res) {

    const data2 =req.body;
    console.log(data2);
    let Date=data2.Date,id=data2.id;
    const sql = 'UPDATE mouvements SET dateretour=? WHERE idmouvements=?'
   //JOIN commandes ON materiels.idcommande=commandes.idcommandes JOIN consommables ON materiels.idconsommable=consommables.idconsommables JOIN services ON materiels.idservice=services.idservices 
    connection.query(sql, [Date,id], function(err, results) {
      if (err) throw err;
      res.send(results); 
    });
  });
  router.post('/Mouvement/comretour', function(req, res) {

    const data2 =req.body;
    console.log(`${data2.com} et ${data2.id}`);
    let com=data2.com,id=data2.id;
    const sql = 'UPDATE mouvements SET commentaireretour=? WHERE idmouvements=?'
   //JOIN commandes ON materiels.idcommande=commandes.idcommandes JOIN consommables ON materiels.idconsommable=consommables.idconsommables JOIN services ON materiels.idservice=services.idservices 
    connection.query(sql, [com,id], function(err, results) {
      if (err) throw err;
      res.send(results); 
    });
  });
  

                                              
   
  module.exports = router;